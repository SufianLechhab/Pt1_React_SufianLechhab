import Persona from './Persona';

class Professor extends Persona {
  constructor(firstName, lastName, age, birthDate, dni, numStudents) {
    super(firstName, lastName, age, birthDate, dni);
    this.numStudents = numStudents; 
  }
}

export default Professor;
