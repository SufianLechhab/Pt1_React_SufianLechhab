import Persona from './Persona';

class Estudiant extends Persona {
  constructor(firstName, lastName, age, birthDate, dni, course, grade) {
    super(firstName, lastName, age, birthDate, dni);
    this.course = course; 
    this.grade = grade;   
  }
}

export default Estudiant;
