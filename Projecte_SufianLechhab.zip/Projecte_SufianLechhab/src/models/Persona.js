class Persona {
    constructor(firstName, lastName, age, birthDate, dni) {
      this.firstName = firstName; 
      this.lastName = lastName;  
      this.age = age;            
      this.birthDate = birthDate; 
      this.dni = dni;            
    }
  }
  
  export default Persona;
  