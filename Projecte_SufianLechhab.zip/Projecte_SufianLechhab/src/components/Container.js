import React, { useState } from 'react';
import DataTable from './DataTable';

const Container = () => {
  const [title, setTitle] = useState('Institut Virtual');
  const [data, setData] = useState([
    { nom: 'Juan', cognoms: 'Perez', edat: 30, dataNaixement: '01-01-1990', dni: '12345678A', nota: 6 },
    { nom: 'Maria', cognoms: 'Lopez', edat: 25, dataNaixement: '15-05-1995', dni: '87654321B', nota: 7.2 },
    { nom: 'Juan', cognoms: 'Perez', edat: 30, dataNaixement: '01-01-1990', dni: '12345678A', nota: 6 },
    { nom: 'Maria', cognoms: 'Lopez', edat: 25, dataNaixement: '15-05-1995', dni: '87654321B', nota: 7.2 },
    { nom: 'Maria', cognoms: 'Lopez', edat: 28, dataNaixement: '15-05-1995', dni: '87654321B', nota: 8 },  
    { nom: 'Carlos', cognoms: 'Garcia', edat: 35, dataNaixement: '10-11-1988', dni: '11223344C', nota: 7 },  
    { nom: 'Ana', cognoms: 'Martinez', edat: 22, dataNaixement: '20-08-2001', dni: '22334455D', nota: 9 },  
    { nom: 'Jose', cognoms: 'Sanchez', edat: 40, dataNaixement: '30-03-1983', dni: '33445566E', nota: 5 },  
    { nom: 'Elena', cognoms: 'Gomez', edat: 25, dataNaixement: '12-12-1997', dni: '44556677F', nota: 6 } 

    // Altres registres...
  ]);
  const [columns, setColumns] = useState([
    { field: 'nom', header: 'Nom' },
    { field: 'cognoms', header: 'Cognoms' },
    { field: 'edat', header: 'Edat' },
    { field: 'dataNaixement', header: 'Data de naixement' },
    { field: 'dni', header: 'DNI' },
    { field: 'nota', header: 'Nota' },
  ]);

  // Totalitzar una columna
  const totalNota = data.reduce((sum, item) => sum + (item.nota || 0), 0);

  // Funció per ordenar
  const sortData = (field) => {
    const sorted = [...data].sort((a, b) => (a[field] > b[field] ? 1 : -1));
    setData(sorted);
  };

  // Funció per filtrar
  const filterData = (field, value) => {
    const filtered = data.filter((item) => item[field] === value);
    setData(filtered);
  };

  return (
    <div>
      <h1>{title}</h1>
      <button onClick={() => setTitle(prompt('Nou títol:'))}>Canvia títol</button>
      <button onClick={() => sortData('nota')}>Ordenar per Nota</button>
      <button onClick={() => setData(data)}>Reiniciar Ordre</button>
      <button onClick={() => filterData('curs', '2n DAW')}>Filtrar per 2n DAW</button>
      <button onClick={() => setData(data)}>Eliminar Filtre</button>
      <DataTable columns={columns} data={data} />
      <p>Total columna Nota: {totalNota}</p>
    </div>
  );
};

export default Container;
